USE master ;  
GO  
CREATE DATABASE group7  
ON   
( NAME = Sales_dat,  
    FILENAME = 'Desktop\group7.mdf',  
    SIZE = 10,  
    MAXSIZE = 50,  
    FILEGROWTH = 5 )  
LOG ON  
( NAME = Sales_log,  
    FILENAME = 'Desktop\group7_log.ldf',  
    SIZE = 5MB,  
    MAXSIZE = 25MB,  
    FILEGROWTH = 5MB ) ;  
GO   