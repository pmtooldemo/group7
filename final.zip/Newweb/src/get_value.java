import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.jdbc.PreparedStatement;

@SuppressWarnings("unused")
public class get_value
{
	@SuppressWarnings("null")
	public void get_value(String ten,String sdt,String email,String diachi,String yeucau) throws SQLException 
	{
		Connection con = null;
		PreparedStatement pr =null;
		java.sql.PreparedStatement rs = null;
		String url = "jdbc:mysql://127.0.0.1/teamapp?useUnicode=true&characterEncoding=utf8&useSSL=false";
		try {
			con = DriverManager.getConnection(url, "root", "thanhlong");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql = "insert into khachhang(ten,sdt,email,diachi,yeucau) values(?,?,?,?)";
		try {
			rs=con.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
		pr.setString(1,ten);
		pr.setString(2, sdt);
		pr.setString(3, email);
		pr.setString(4, diachi);
		pr.setString(5, yeucau);
		
		pr.executeUpdate();
	} catch (Exception e) {
		// TODO: handle exception
		System.err.println(e)	;
	}
		
	
	}
}