$("#show-popup-button").on("click", function() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
});