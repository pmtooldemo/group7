package AppProject.src;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.dbutils.DbUtils;

import com.mysql.cj.api.jdbc.Statement;
import com.mysql.cj.api.x.DatabaseObject.DbObjectType;
import com.mysql.cj.jdbc.PreparedStatement;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.nio.channels.SelectableChannel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TeamApp extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	int xMouse;
	int yMouse;
	private JTable table;
	private JTextField txttimkiem;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeamApp frame = new TeamApp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TeamApp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 50, 1200, 750);
		contentPane = new JPanel();
		contentPane.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent evt) {
				int x = evt.getXOnScreen();
				int y = evt.getYOnScreen();
				setLocation(x - xMouse,y - yMouse);
			}
		});
		contentPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent evt) {
				xMouse = evt.getX();
				yMouse = evt.getY();
				
			}
		});
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, 0, 176, 750);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(UIManager.getColor("RadioButtonMenuItem.foreground"));
		panel_2.setBounds(0, 0, 176, 33);
		panel.add(panel_2);
		
		JLabel lblDanhMcKhch = new JLabel("Danh m\u1EE5c kh\u00E1ch h\u00E0ng");
		lblDanhMcKhch.setForeground(UIManager.getColor("ScrollBar.track"));
		lblDanhMcKhch.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDanhMcKhch.setBackground(UIManager.getColor("RadioButtonMenuItem.selectionForeground"));
		panel_2.add(lblDanhMcKhch);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(UIManager.getColor("RadioButtonMenuItem.foreground"));
		panel_3.setForeground(UIManager.getColor("RadioButtonMenuItem.foreground"));
		panel_3.setBounds(0, 56, 176, 33);
		panel.add(panel_3);
		
		JLabel lblThngTinNhn = new JLabel("     Ph\u00E2n quy\u1EC1n[Developing]");
		lblThngTinNhn.setForeground(Color.WHITE);
		lblThngTinNhn.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblThngTinNhn.setBackground(Color.WHITE);
		panel_3.add(lblThngTinNhn);
		
		JPanel panel_4 = new JPanel();
		panel_4.setForeground(Color.BLACK);
		panel_4.setBackground(Color.BLACK);
		panel_4.setBounds(0, 120, 176, 33);
		panel.add(panel_4);
		
		JLabel lblThotdeveloping = new JLabel("     Tho\u00E1t[Developing]");
		lblThotdeveloping.setForeground(Color.WHITE);
		lblThotdeveloping.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblThotdeveloping.setBackground(Color.WHITE);
		panel_4.add(lblThotdeveloping);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(UIManager.getColor("RadioButtonMenuItem.selectionBackground"));
		panel_1.setBounds(177, 0, 1023, 750);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
	
		
		JLabel lblX = new JLabel("X");
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent evt) {
				System.exit(0);
			}
		});
		lblX.setBounds(983, 11, 30, 25);
		lblX.setFont(new Font("Tahoma", Font.PLAIN, 30));
		panel_1.add(lblX);
		
		JScrollPane jtable = new JScrollPane();
		jtable.setBounds(50, 159, 943, 580);
		panel_1.add(jtable);
		
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
				new Object[][] {
					{null, null, null, null, null},
				},
				new String[] {
						"Phone","Name", "Email", "address", "Rrequest"
				}
			));
			table.getColumnModel().getColumn(0).setMinWidth(0);
			table.getColumnModel().getColumn(0).setMaxWidth(0);
			jtable.setViewportView(table);
			initDataFromCSDL();
		
		JLabel lblNewLabel = new JLabel("Danh M\u1EE5c Kh\u00E1ch H\u00E0ng");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 40));
		lblNewLabel.setBounds(324, 47, 590, 60);
		panel_1.add(lblNewLabel);
		
		txttimkiem = new JTextField();
		txttimkiem.setBounds(594, 118, 155, 25);
		panel_1.add(txttimkiem);
		txttimkiem.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("T\u00EAn kh\u00E1ch h\u00E0ng");
		lblNewLabel_1.setBounds(497, 121, 98, 14);
		panel_1.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("T\u00ECm ki\u1EBFm");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String ten = txttimkiem.getText().trim().toUpperCase();
				String sql = "";
				if (ten.isEmpty()){
					sql = "select * from khachhang";
				} else {
					sql = "select * from khachhang where upper(ten) like '%" + ten + "%'";
				}
				
				String url = "jdbc:mysql://127.0.0.1/teamapp?useUnicode=true&characterEncoding=utf8&useSSL=false";
				String username = "root";
				String password = "thanhlong";
				
				try (Connection con = DriverManager.getConnection(url, username, password);
						java.sql.Statement pr = con.createStatement();
						ResultSet rs = pr.executeQuery(sql)){
					
					if (rs != null){
						DefaultTableModel model = (DefaultTableModel) table.getModel();
						model.setRowCount(0);
						while (rs.next()){
							model.addRow(new Object[]{rs.getInt("id"),rs.getString("ten"), rs.getString("sdt"), rs.getString("email"), rs.getString("diachi"),rs.getString("yeucau")});
						}
					} else {
						JOptionPane.showMessageDialog(null, "Không tìm thấy dữ liệu.");
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Đã có lỗi xãy ra.");
					e2.printStackTrace();
				} 
			}
		});
		btnNewButton.setBounds(778, 118, 89, 23);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cập Nhật");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (JOptionPane.showConfirmDialog(rootPane, "Bạn có chắn chắc muốn cập nhât dữ liệu không?", "Xác Nhận", 
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
				String url = "jdbc:mysql://127.0.0.1/teamapp?useUnicode=true&characterEncoding=utf8&useSSL=false";
				Connection con = null;
				ResultSet rs =null;
				try {
					con = DriverManager.getConnection(url, "root", "thanhlong");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				java.sql.PreparedStatement pt =null;
				String sql ="select * from khachhang";
				try {
					pt = con.prepareStatement(sql);
					rs=pt.executeQuery(sql);
				table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
					
				} catch (Exception e) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null,e);
				}
			}
		}
	});
		btnNewButton_1.setBounds(903, 118, 90, 23);
		panel_1.add(btnNewButton_1);
		
		JButton btnXoa = new JButton("Xóa");
		btnXoa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (JOptionPane.showConfirmDialog(rootPane, "Bạn có chắn chắc muốn xóa dữ không?", "Xác Nhận", 
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
					java.sql.Statement st = null;
					ResultSet rs = null;
					String sql ="delete from khachhang";
					String url = "jdbc:mysql://127.0.0.1/teamapp?useUnicode=true&characterEncoding=utf8&useSSL=false";
					try (Connection con = DriverManager.getConnection(url, "root", "thanhlong");
							java.sql.PreparedStatement pr = con.prepareStatement("delete from khachhang where id = ?")){
						pr.setInt(1, (int) table.getValueAt(table.getSelectedRow(), 0));
						if (pr.executeUpdate() == 1){
							DefaultTableModel model = (DefaultTableModel) table.getModel();
							model.removeRow(table.getSelectedRow());
							
							JOptionPane.showMessageDialog(null, "Xóa thành công.");
						} else {
							JOptionPane.showMessageDialog(null, "Xóa không thành công.");
						}
					} catch (SQLException e2) {
						JOptionPane.showMessageDialog(null, "Đã có lỗi xãy ra.");
						e2.printStackTrace();
					}
			
				}
			}
		});
		btnXoa.setBounds(390, 118, 70, 23);
		panel_1.add(btnXoa);
		
		JButton btnThm = new JButton("Thêm");
		btnThm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(rootPane, "Bạn có chắn chắc muốn thêm dữ không?", "Xác Nhận", 
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
					java.sql.Statement st = null;
					ResultSet rs = null;
					String sql ="insert into khachhang(ten,sdt,email,diachi,yeucau) values();";
					String url = "jdbc:mysql://127.0.0.1/teamapp?useUnicode=true&characterEncoding=utf8&useSSL=false";
					try (Connection con = DriverManager.getConnection(url, "root", "thanhlong");
							java.sql.PreparedStatement pr = con.prepareStatement(sql)){
						pr.setInt(1, (int) table.getValueAt(table.getSelectedRow(), 0));
						if (pr.executeUpdate() == 1){
							DefaultTableModel model = (DefaultTableModel) table.getModel();
							model.addRow(new Object[]{ rs.getString("sdt"),rs.getString("ten"), rs.getString("email"), rs.getString("diachi"),rs.getString("yeucau")});
							
							JOptionPane.showMessageDialog(null, "thêm thành công.");
						} else {
							JOptionPane.showMessageDialog(null, "thêm không thành công.");
						}
					} catch (SQLException e2) {
						JOptionPane.showMessageDialog(null, "Đã có lỗi xãy ra.");
						e2.printStackTrace();
					}
			
				}
			}
		});
		btnThm.setBounds(258, 118, 81, 23);
		panel_1.add(btnThm);
		setUndecorated(true);
		setResizable(true);
	}
	private void initDataFromCSDL() {
		String url = "jdbc:mysql://127.0.0.1/teamapp?useUnicode=true&characterEncoding=utf8&useSSL=false";
		String username = "root";
		String password = "thanhlong";
		
		try (Connection con = DriverManager.getConnection(url, username, password);
				java.sql.Statement pr = con.createStatement();
				ResultSet rs = pr.executeQuery("select * from khachhang")){
			
			if (rs != null){
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				model.setRowCount(0);
				while (rs.next()){
					model.addRow(new Object[]{ rs.getString("sdt"),rs.getString("ten"), rs.getString("email"), rs.getString("diachi"),rs.getString("yeucau")});
				}
			} else {
				JOptionPane.showMessageDialog(null, "No data available.");
			}
		} catch (Exception e2) {
			JOptionPane.showMessageDialog(null, "Error occour.");
			e2.printStackTrace();
		} 
	}
}
